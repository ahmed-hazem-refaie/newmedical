// Just an empty JavaScript file to use to test ScriptLoader
